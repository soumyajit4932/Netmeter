package com.ankit.netmeter

object PrefKeys {
    const val FILE = "netmeter"
}

object Prefs {

    private const val KEY_METER_ON = "meter_on"
    private const val KEY_ALERT_MB = "alert_mb"
    private const val KEY_ALERT_DAY = "alert_day"
    private const val KEY_ALERTED = "alerted_uids"

    /** 0 means alerts are off. */
    const val ALERT_OFF = 0
    const val ALERT_DEFAULT_MB = 100

    private fun store(context: android.content.Context) =
        context.getSharedPreferences(PrefKeys.FILE, android.content.Context.MODE_PRIVATE)

    // ---- meter ------------------------------------------------------------

    fun isMeterEnabled(context: android.content.Context): Boolean =
        store(context).getBoolean(KEY_METER_ON, false)

    fun setMeterEnabled(context: android.content.Context, enabled: Boolean) {
        store(context).edit().putBoolean(KEY_METER_ON, enabled).apply()
    }

    // ---- background spike alerts -------------------------------------------

    /** Megabytes of background traffic in a day before an app gets flagged. */
    fun alertThresholdMb(context: android.content.Context): Int =
        store(context).getInt(KEY_ALERT_MB, ALERT_DEFAULT_MB)

    fun setAlertThresholdMb(context: android.content.Context, mb: Int) {
        store(context).edit().putInt(KEY_ALERT_MB, mb).apply()
    }

    /** One alert per app per day, so a heavy app doesn't nag all afternoon. */
    fun shouldAlert(context: android.content.Context, day: Long, uid: Int): Boolean {
        val prefs = store(context)
        if (prefs.getLong(KEY_ALERT_DAY, 0L) != day) return true
        return uid.toString() !in (prefs.getStringSet(KEY_ALERTED, emptySet()) ?: emptySet())
    }

    fun markAlerted(context: android.content.Context, day: Long, uid: Int) {
        val prefs = store(context)
        val sameDay = prefs.getLong(KEY_ALERT_DAY, 0L) == day
        val existing =
            if (sameDay) (prefs.getStringSet(KEY_ALERTED, emptySet()) ?: emptySet()) else emptySet()
        prefs.edit()
            .putLong(KEY_ALERT_DAY, day)
            .putStringSet(KEY_ALERTED, existing + uid.toString())
            .apply()
    }
}
