package com.ankit.netmeter

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * The app is a meter, so it is styled like one: a dark instrument face, two
 * fixed channel colours (teal = coming in, ember = going out) used everywhere
 * a direction is shown, and monospaced digits so numbers don't jitter as they
 * tick over.
 */
object Ink {
    val Background = Color(0xFF080B10)
    val Surface = Color(0xFF111823)
    val Raised = Color(0xFF161F2C)
    val Hairline = Color(0xFF1E2836)
    val Down = Color(0xFF39E0C8)
    val Up = Color(0xFFFF9548)
    val Text = Color(0xFFE6EDF5)
    val Muted = Color(0xFF8496AB)
    val Faint = Color(0xFF56657A)
}

/** Big numbers: monospaced and tight, like a readout. */
val Readout = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Bold,
    fontSize = 34.sp,
    letterSpacing = (-1).sp
)

val ReadoutSmall = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Bold,
    fontSize = 20.sp,
    letterSpacing = (-0.5).sp
)

/** Instrument labels: small, uppercase, widely tracked. */
val Legend = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontWeight = FontWeight.Medium,
    fontSize = 10.sp,
    letterSpacing = 1.6.sp
)

val Body = TextStyle(
    fontFamily = FontFamily.SansSerif,
    fontWeight = FontWeight.Normal,
    fontSize = 14.sp
)

@Composable
fun NetMeterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink.Background,
            surface = Ink.Surface,
            primary = Ink.Down,
            onPrimary = Ink.Background,
            onBackground = Ink.Text,
            onSurface = Ink.Text
        ),
        content = content
    )
}
