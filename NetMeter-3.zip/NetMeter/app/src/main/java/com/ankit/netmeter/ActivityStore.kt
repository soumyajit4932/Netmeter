package com.ankit.netmeter

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** One recorded burst: an app moved this much data around this time. */
data class ActivityEntry(
    val uid: Int,
    val from: Long,
    val to: Long,
    val usage: Usage
)

/**
 * Android will tell you a running total per app, but not when it happened at
 * any useful resolution. So we take our own reading every minute while the
 * meter is running and store the difference. Over a day that becomes a
 * timeline of who moved data and at what o'clock.
 */
class ActivityStore(context: Context) : SQLiteOpenHelper(context, NAME, null, VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE activity(
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 uid INTEGER NOT NULL,
                 from_at INTEGER NOT NULL,
                 to_at INTEGER NOT NULL,
                 mobile INTEGER NOT NULL,
                 wifi INTEGER NOT NULL,
                 fg INTEGER NOT NULL,
                 bg INTEGER NOT NULL)"""
        )
        db.execSQL("CREATE INDEX idx_activity_to ON activity(to_at)")
        db.execSQL(
            """CREATE TABLE snapshot(
                 uid INTEGER PRIMARY KEY,
                 day INTEGER NOT NULL,
                 taken_at INTEGER NOT NULL,
                 mobile INTEGER NOT NULL,
                 wifi INTEGER NOT NULL,
                 fg INTEGER NOT NULL,
                 bg INTEGER NOT NULL)"""
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        db.execSQL("DROP TABLE IF EXISTS activity")
        db.execSQL("DROP TABLE IF EXISTS snapshot")
        onCreate(db)
    }

    /**
     * Read every app's running total, compare with last time, write down what
     * changed. Call this on a background thread.
     */
    fun sample(repo: NetStatsRepo) {
        if (!repo.hasUsageAccess()) return

        val (dayStart, now) = NetStatsRepo.todayRange()
        val current = repo.usageByUid(dayStart, now)
        if (current.isEmpty()) return

        val db = writableDatabase
        val previous = readSnapshot(db, dayStart)
        // First reading of the day (or after a restart) is the baseline only —
        // otherwise the whole day would land in a single one-minute burst.
        val baseline = previous.isEmpty()
        val takenAt = previous.values.firstOrNull()?.second ?: now

        db.beginTransaction()
        try {
            if (!baseline) {
                for ((uid, usage) in current) {
                    val before = previous[uid]?.first ?: Usage()
                    val delta = Usage(
                        mobile = (usage.mobile - before.mobile).coerceAtLeast(0),
                        wifi = (usage.wifi - before.wifi).coerceAtLeast(0),
                        foreground = (usage.foreground - before.foreground).coerceAtLeast(0),
                        background = (usage.background - before.background).coerceAtLeast(0)
                    )
                    if (delta.total < MIN_BYTES) continue

                    db.insert("activity", null, ContentValues().apply {
                        put("uid", uid)
                        put("from_at", takenAt)
                        put("to_at", now)
                        put("mobile", delta.mobile)
                        put("wifi", delta.wifi)
                        put("fg", delta.foreground)
                        put("bg", delta.background)
                    })
                }
            }

            db.delete("snapshot", null, null)
            for ((uid, usage) in current) {
                db.insert("snapshot", null, ContentValues().apply {
                    put("uid", uid)
                    put("day", dayStart)
                    put("taken_at", now)
                    put("mobile", usage.mobile)
                    put("wifi", usage.wifi)
                    put("fg", usage.foreground)
                    put("bg", usage.background)
                })
            }

            db.delete("activity", "to_at < ?", arrayOf((now - KEEP_MS).toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun readSnapshot(
        db: SQLiteDatabase,
        dayStart: Long
    ): Map<Int, Pair<Usage, Long>> {
        val out = HashMap<Int, Pair<Usage, Long>>()
        db.rawQuery(
            "SELECT uid, taken_at, mobile, wifi, fg, bg FROM snapshot WHERE day = ?",
            arrayOf(dayStart.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out[c.getInt(0)] = Usage(
                    c.getLong(2), c.getLong(3), c.getLong(4), c.getLong(5)
                ) to c.getLong(1)
            }
        }
        return out
    }

    /**
     * Newest first. Consecutive readings from the same app inside [mergeMs] are
     * folded together so a long download reads as one session, not forty rows.
     */
    fun recent(since: Long, limit: Int = 60, mergeMs: Long = 10 * 60_000L): List<ActivityEntry> {
        val raw = ArrayList<ActivityEntry>()
        readableDatabase.rawQuery(
            """SELECT uid, from_at, to_at, mobile, wifi, fg, bg FROM activity
               WHERE to_at >= ? ORDER BY to_at DESC LIMIT 400""",
            arrayOf(since.toString())
        ).use { c ->
            while (c.moveToNext()) {
                raw.add(
                    ActivityEntry(
                        uid = c.getInt(0),
                        from = c.getLong(1),
                        to = c.getLong(2),
                        usage = Usage(c.getLong(3), c.getLong(4), c.getLong(5), c.getLong(6))
                    )
                )
            }
        }

        val merged = ArrayList<ActivityEntry>()
        for (entry in raw) {
            val last = merged.lastOrNull()
            if (last != null && last.uid == entry.uid && last.from - entry.to <= mergeMs) {
                merged[merged.lastIndex] = last.copy(
                    from = entry.from,
                    usage = last.usage + entry.usage
                )
            } else {
                merged.add(entry)
            }
        }
        return merged.take(limit)
    }

    /** Everything logged for one app since [since], newest first. */
    fun forApp(uid: Int, since: Long, limit: Int = 40): List<ActivityEntry> =
        recent(since, limit = 400).filter { it.uid == uid }.take(limit)

    companion object {
        private const val NAME = "netmeter_activity.db"
        private const val VERSION = 1

        /** Ignore dribbles below this — keeps the log readable. */
        private const val MIN_BYTES = 128L * 1024L

        /** Keep a week of history. */
        private const val KEEP_MS = 7L * 24 * 60 * 60 * 1000
    }
}
