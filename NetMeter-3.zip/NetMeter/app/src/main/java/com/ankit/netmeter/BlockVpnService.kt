package com.ankit.netmeter

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * Cuts an app off from the network without root.
 *
 * The trick: Android lets a VPN declare which packages it captures. We capture
 * *only* the blocked apps and then never forward a single packet — their
 * traffic goes into the tunnel and stops there. Every other app bypasses the
 * VPN entirely and is untouched, so nothing is slowed down or routed anywhere.
 * No traffic leaves the phone and no server is involved.
 *
 * Android allows one active VPN at a time, so this cannot run alongside a
 * different VPN app.
 */
class BlockVpnService : VpnService() {

    private var tunnel: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            teardown()
            stopSelf()
            return START_NOT_STICKY
        }
        rebuild()
        return START_STICKY
    }

    override fun onRevoke() {
        teardown()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun rebuild() {
        teardown()

        val blocked = Blocklist.packages(this).filter { it != packageName }
        if (blocked.isEmpty()) {
            stopSelf()
            return
        }

        val builder = Builder()
            .setSession("Net Meter — blocked apps")
            .addAddress(IPV4_ADDRESS, 32)
            .addRoute("0.0.0.0", 0)
            .setBlocking(false)

        // Catch IPv6 too, or a blocked app could still reach the internet.
        runCatching {
            builder.addAddress(IPV6_ADDRESS, 128)
            builder.addRoute("::", 0)
        }

        var captured = 0
        for (pkg in blocked) {
            try {
                builder.addAllowedApplication(pkg)
                captured++
            } catch (e: PackageManager.NameNotFoundException) {
                // uninstalled since it was blocked — ignore
            }
        }

        // With no allowed packages the VPN would capture everything, which is
        // the opposite of what we want. Bail out instead.
        if (captured == 0) {
            stopSelf()
            return
        }

        tunnel = runCatching { builder.establish() }.getOrNull()
        if (tunnel == null) stopSelf()
    }

    private fun teardown() {
        runCatching { tunnel?.close() }
        tunnel = null
    }

    companion object {
        const val ACTION_STOP = "com.ankit.netmeter.STOP_BLOCK"

        private const val IPV4_ADDRESS = "10.111.222.1"
        private const val IPV6_ADDRESS = "fd00:1:6e65:746d::1"

        /**
         * Call after any change to the blocklist. Starts, restarts or stops the
         * tunnel to match. Consent must already have been granted — check
         * [VpnService.prepare] first.
         */
        fun sync(context: Context) {
            val intent = Intent(context, BlockVpnService::class.java)
            if (Blocklist.packages(context).isEmpty()) {
                context.startService(intent.setAction(ACTION_STOP))
            } else {
                context.startService(intent)
            }
        }
    }
}
