package com.ankit.netmeter

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface

/**
 * The status bar can only show a small icon, not text. So we render the speed
 * into a bitmap and hand that to the notification as its small icon — this is
 * how the number ends up sitting up there next to the battery percentage.
 */
object SpeedIcon {

    private const val SIZE = 96

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    fun build(bytesPerSec: Long): Bitmap {
        val (value, unit) = Format.speedParts(bytesPerSec)
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        drawFitted(canvas, value, 54f, 46f)
        drawFitted(canvas, unit, 34f, 90f)

        return bmp
    }

    private fun drawFitted(canvas: Canvas, text: String, size: Float, baseline: Float) {
        paint.textSize = size
        val width = paint.measureText(text)
        val max = SIZE * 0.98f
        if (width > max) paint.textSize = size * max / width
        canvas.drawText(text, SIZE / 2f, baseline, paint)
    }
}
