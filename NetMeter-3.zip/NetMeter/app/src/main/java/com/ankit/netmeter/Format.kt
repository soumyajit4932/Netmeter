package com.ankit.netmeter

import java.util.Locale

object Format {

    /** Splits a speed into number and unit so the status-bar icon can stack them on two lines. */
    fun speedParts(bytesPerSec: Long): Pair<String, String> {
        val b = if (bytesPerSec < 0) 0L else bytesPerSec
        val kb = b / 1024.0
        val mb = kb / 1024.0
        return when {
            kb < 1000 -> String.format(Locale.US, "%.0f", kb) to "KB/s"
            mb < 10 -> String.format(Locale.US, "%.1f", mb) to "MB/s"
            else -> String.format(Locale.US, "%.0f", mb) to "MB/s"
        }
    }

    fun speed(bytesPerSec: Long): String {
        val (v, u) = speedParts(bytesPerSec)
        return "$v $u"
    }

    fun bytes(value: Long): String {
        val b = if (value < 0) 0.0 else value.toDouble()
        return when {
            b < 1024 -> "${b.toInt()} B"
            b < 1024.0 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
            b < 1024.0 * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024))
            else -> String.format(Locale.US, "%.2f GB", b / (1024.0 * 1024 * 1024))
        }
    }

    /** Number and unit separately, for the big readouts on the cards. */
    fun bytesParts(value: Long): Pair<String, String> {
        val b = if (value < 0) 0.0 else value.toDouble()
        return when {
            b < 1024 -> "${b.toInt()}" to "B"
            b < 1024.0 * 1024 -> String.format(Locale.US, "%.1f", b / 1024.0) to "KB"
            b < 1024.0 * 1024 * 1024 -> String.format(Locale.US, "%.1f", b / (1024.0 * 1024)) to "MB"
            else -> String.format(Locale.US, "%.2f", b / (1024.0 * 1024 * 1024)) to "GB"
        }
    }
}
