package com.ankit.netmeter

import android.content.Context

/** The set of packages the user has cut off. Kept as plain package names. */
object Blocklist {

    private const val FILE = "netmeter_block"
    private const val KEY = "blocked"

    private fun store(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun packages(context: Context): Set<String> =
        store(context).getStringSet(KEY, emptySet()) ?: emptySet()

    fun contains(context: Context, pkg: String?): Boolean =
        pkg != null && pkg in packages(context)

    fun set(context: Context, pkg: String, blocked: Boolean) {
        val next = packages(context).toMutableSet()
        if (blocked) next.add(pkg) else next.remove(pkg)
        store(context).edit().putStringSet(KEY, next).apply()
    }

    fun clear(context: Context) {
        store(context).edit().remove(KEY).apply()
    }
}
