package com.ankit.netmeter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat

class SpeedService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var worker: HandlerThread
    private lateinit var workerHandler: Handler

    private lateinit var repo: NetStatsRepo
    private lateinit var store: ActivityStore

    private var lastRx = 0L
    private var lastTx = 0L
    private var lastTime = 0L
    private var ticks = 0
    private var todayLine = ""

    /** Once a second: refresh the number in the status bar. */
    private val speedTick = object : Runnable {
        override fun run() {
            updateSpeed()
            handler.postDelayed(this, SPEED_INTERVAL_MS)
        }
    }

    /** Once a minute, off the main thread: write down who used what. */
    private val activityTick = object : Runnable {
        override fun run() {
            runCatching { store.sample(repo) }
            runCatching { checkBackgroundAlerts() }
            workerHandler.postDelayed(this, ACTIVITY_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repo = NetStatsRepo(this)
        store = ActivityStore(applicationContext)
        createChannel()
        running = true

        lastRx = TrafficStats.getTotalRxBytes()
        lastTx = TrafficStats.getTotalTxBytes()
        lastTime = SystemClock.elapsedRealtime()

        startInForeground(build(0, 0, 0))
        handler.post(speedTick)

        worker = HandlerThread("netmeter-activity").also { it.start() }
        workerHandler = Handler(worker.looper)
        workerHandler.post(activityTick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(speedTick)
        if (::workerHandler.isInitialized) workerHandler.removeCallbacks(activityTick)
        if (::worker.isInitialized) worker.quitSafely()
        super.onDestroy()
    }

    // -----------------------------------------------------------------------

    private fun updateSpeed() {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val now = SystemClock.elapsedRealtime()
        val seconds = (now - lastTime) / 1000.0

        val down = if (seconds > 0) ((rx - lastRx) / seconds).toLong().coerceAtLeast(0) else 0
        val up = if (seconds > 0) ((tx - lastTx) / seconds).toLong().coerceAtLeast(0) else 0

        lastRx = rx
        lastTx = tx
        lastTime = now

        // Reading usage records is comparatively expensive — refresh every 30s.
        if (ticks % 30 == 0) {
            todayLine = if (repo.hasUsageAccess()) {
                val (start, end) = NetStatsRepo.todayRange()
                val u = repo.deviceUsage(start, end)
                "Today  ${Format.bytes(u.total)}  ·  mobile ${Format.bytes(u.mobile)}"
            } else {
                "Turn on usage access to see today's total"
            }
        }
        ticks++

        notificationManager().notify(NOTIF_ID, build(down, up, down + up))
    }

    // ---- background spike alerts -------------------------------------------

    /**
     * Flags an app that has quietly moved more than the user's limit today
     * while it was not on screen. One notification per app per day.
     */
    private fun checkBackgroundAlerts() {
        val thresholdMb = Prefs.alertThresholdMb(this)
        if (thresholdMb <= Prefs.ALERT_OFF) return
        if (!repo.hasUsageAccess()) return

        val (dayStart, now) = NetStatsRepo.todayRange()
        val limit = thresholdMb * 1024L * 1024L

        for ((uid, usage) in repo.usageByUid(dayStart, now)) {
            if (usage.background < limit) continue
            if (!Prefs.shouldAlert(this, dayStart, uid)) continue

            val name = repo.describe(uid).first
            notificationManager().notify(
                ALERT_BASE_ID + (uid % 900),
                alertNotification(name, usage)
            )
            Prefs.markAlerted(this, dayStart, uid)
        }
    }

    private fun alertNotification(name: String, usage: Usage): android.app.Notification {
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val body = "${Format.bytes(usage.background)} today while you weren't in the app" +
            if (usage.mobile > 0) " · ${Format.bytes(usage.mobile)} of it on mobile data." else "."

        return NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_alert)
            .setContentTitle("$name is busy in the background")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\n\nTap to review and restrict it."))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
    }

    private fun build(down: Long, up: Long, combined: Long): android.app.Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, SpeedService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(IconCompat.createWithBitmap(SpeedIcon.build(combined)))
            .setContentTitle("↓ ${Format.speed(down)}     ↑ ${Format.speed(up)}")
            .setContentText(todayLine)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun startInForeground(notification: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun createChannel() {
        val live = NotificationChannel(
            CHANNEL_ID,
            "Live speed",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "The always-on speed readout in your status bar"
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }

        val alerts = NotificationChannel(
            ALERT_CHANNEL_ID,
            "Background spikes",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "When an app quietly uses a lot of data with the screen off it"
        }

        notificationManager().createNotificationChannel(live)
        notificationManager().createNotificationChannel(alerts)
    }

    private fun notificationManager() =
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_ID = "live_speed"
        const val ALERT_CHANNEL_ID = "background_spikes"
        const val NOTIF_ID = 1001
        const val ALERT_BASE_ID = 2000
        const val ACTION_STOP = "com.ankit.netmeter.STOP"

        private const val SPEED_INTERVAL_MS = 1_000L
        private const val ACTIVITY_INTERVAL_MS = 60_000L

        @Volatile
        var running = false
            private set

        fun start(context: Context) {
            context.startForegroundService(Intent(context, SpeedService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SpeedService::class.java))
        }
    }
}
