package com.ankit.netmeter

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * mobile/wifi answers "over what". foreground/background answers "were you
 * actually looking at it". Both pairs add up to the same total.
 */
data class Usage(
    val mobile: Long = 0,
    val wifi: Long = 0,
    val foreground: Long = 0,
    val background: Long = 0
) {
    val total: Long get() = mobile + wifi

    /** 0f..1f — how much of this happened while the app was not on screen. */
    val backgroundShare: Float
        get() = if (total > 0) (background.toFloat() / total).coerceIn(0f, 1f) else 0f

    operator fun plus(other: Usage) = Usage(
        mobile + other.mobile,
        wifi + other.wifi,
        foreground + other.foreground,
        background + other.background
    )
}

data class AppUsage(
    val uid: Int,
    val name: String,
    val packageName: String?,
    val icon: Drawable?,
    val usage: Usage
)

data class MonthUsage(val label: String, val usage: Usage)

/** One slot of the day. 24 of these make the "when" chart. */
data class HourSlot(val hour: Int, val usage: Usage)

class NetStatsRepo(private val context: Context) {

    private val manager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    private val pm = context.packageManager

    // ---- permission -------------------------------------------------------

    fun hasUsageAccess(): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    // ---- device totals ----------------------------------------------------

    fun deviceUsage(start: Long, end: Long): Usage {
        var out = Usage()
        for (type in TYPES) {
            val bytes = try {
                val b = manager.querySummaryForDevice(type, null, start, end)
                b.rxBytes + b.txBytes
            } catch (e: Exception) {
                0L
            }
            out = out + if (type == MOBILE) Usage(mobile = bytes) else Usage(wifi = bytes)
        }
        return out
    }

    // ---- per app ----------------------------------------------------------

    /** Raw totals keyed by uid — the activity log diffs these minute to minute. */
    fun usageByUid(start: Long, end: Long): Map<Int, Usage> {
        val out = HashMap<Int, Usage>()
        for (type in TYPES) {
            val stats = try {
                manager.querySummary(type, null, start, end)
            } catch (e: Exception) {
                continue
            }
            val bucket = NetworkStats.Bucket()
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                out[bucket.uid] = (out[bucket.uid] ?: Usage()) + bucket.toUsage(type)
            }
            stats.close()
        }
        return out
    }

    fun appUsage(start: Long, end: Long): List<AppUsage> =
        usageByUid(start, end)
            .filter { it.value.total > 0 }
            .map { (uid, usage) ->
                val (name, pkg, icon) = describe(uid)
                AppUsage(uid, name, pkg, icon, usage)
            }
            .sortedByDescending { it.usage.total }

    // ---- when -------------------------------------------------------------

    /**
     * 24 hourly slots for the day starting at [dayStart].
     *
     * Android stores traffic in blocks rather than second by second, so a block
     * straddling two hours is split between them in proportion to the overlap.
     * The shape of the day is right; the edges are approximate.
     */
    fun hourlyTimeline(dayStart: Long, dayEnd: Long, uid: Int? = null): List<HourSlot> {
        val mobile = LongArray(24)
        val wifi = LongArray(24)
        val fg = LongArray(24)
        val bg = LongArray(24)

        for (type in TYPES) {
            val stats = try {
                if (uid == null) manager.queryDetails(type, null, dayStart, dayEnd)
                else manager.queryDetailsForUid(type, null, dayStart, dayEnd, uid)
            } catch (e: Exception) {
                continue
            }
            val bucket = NetworkStats.Bucket()
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                val bytes = bucket.rxBytes + bucket.txBytes
                if (bytes <= 0) continue

                val from = bucket.startTimeStamp
                val to = bucket.endTimeStamp
                val span = (to - from).coerceAtLeast(1L)
                val foreground = bucket.state == NetworkStats.Bucket.STATE_FOREGROUND

                for (h in 0 until 24) {
                    val hourStart = dayStart + h * HOUR
                    val hourEnd = hourStart + HOUR
                    val overlap = minOf(to, hourEnd) - maxOf(from, hourStart)
                    if (overlap <= 0) continue
                    val share = bytes * overlap / span
                    if (type == MOBILE) mobile[h] += share else wifi[h] += share
                    if (foreground) fg[h] += share else bg[h] += share
                }
            }
            stats.close()
        }

        return (0 until 24).map { h -> HourSlot(h, Usage(mobile[h], wifi[h], fg[h], bg[h])) }
    }

    // ---- naming -----------------------------------------------------------

    fun describe(uid: Int): Triple<String, String?, Drawable?> {
        when (uid) {
            NetworkStats.Bucket.UID_TETHERING -> return Triple("Hotspot / tethering", null, null)
            NetworkStats.Bucket.UID_REMOVED -> return Triple("Uninstalled apps", null, null)
            NetworkStats.Bucket.UID_ALL -> return Triple("All traffic", null, null)
            Process.SYSTEM_UID -> return Triple("Android system", "android", null)
            0 -> return Triple("Kernel", null, null)
        }

        val packages = pm.getPackagesForUid(uid)
        if (packages.isNullOrEmpty()) return Triple("Unknown (uid $uid)", null, null)

        for (pkg in packages) {
            try {
                val info = pm.getApplicationInfo(pkg, 0)
                return Triple(
                    pm.getApplicationLabel(info).toString(),
                    pkg,
                    runCatching { pm.getApplicationIcon(info) }.getOrNull()
                )
            } catch (e: Exception) {
                // another package shares this uid — try the next one
            }
        }
        return Triple(packages.first(), packages.first(), null)
    }

    private fun NetworkStats.Bucket.toUsage(type: Int): Usage {
        val bytes = rxBytes + txBytes
        val foreground = state == NetworkStats.Bucket.STATE_FOREGROUND
        return Usage(
            mobile = if (type == MOBILE) bytes else 0,
            wifi = if (type == MOBILE) 0 else bytes,
            foreground = if (foreground) bytes else 0,
            background = if (foreground) 0 else bytes
        )
    }

    // ---- time ranges ------------------------------------------------------

    companion object {
        private const val MOBILE = ConnectivityManager.TYPE_MOBILE
        private const val WIFI = ConnectivityManager.TYPE_WIFI
        private val TYPES = intArrayOf(MOBILE, WIFI)
        const val HOUR = 60L * 60L * 1000L

        fun todayRange(): Pair<Long, Long> =
            midnight().timeInMillis to System.currentTimeMillis()

        fun dayBounds(): Pair<Long, Long> {
            val start = midnight().timeInMillis
            return start to start + 24 * HOUR
        }

        fun thisMonthRange(): Pair<Long, Long> {
            val cal = midnight().apply { set(Calendar.DAY_OF_MONTH, 1) }
            return cal.timeInMillis to System.currentTimeMillis()
        }

        /** Newest month first. */
        fun lastMonths(count: Int): List<Triple<String, Long, Long>> {
            val fmt = SimpleDateFormat("MMM yyyy", Locale.getDefault())
            val cal = midnight().apply { set(Calendar.DAY_OF_MONTH, 1) }
            val now = System.currentTimeMillis()
            val out = ArrayList<Triple<String, Long, Long>>(count)

            repeat(count) {
                val start = cal.timeInMillis
                val next = (cal.clone() as Calendar).apply { add(Calendar.MONTH, 1) }.timeInMillis
                val end = minOf(next - 1, now)
                if (start < now) out.add(Triple(fmt.format(Date(start)), start, end))
                cal.add(Calendar.MONTH, -1)
            }
            return out
        }

        fun clockLabel(at: Long): String =
            SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(at))

        fun hourLabel(hour: Int): String = when (hour) {
            0 -> "12a"
            12 -> "12p"
            in 1..11 -> "${hour}a"
            else -> "${hour - 12}p"
        }

        private fun midnight(): Calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }
}
