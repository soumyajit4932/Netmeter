package com.ankit.netmeter

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.TrafficStats
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NetMeterTheme { MeterScreen() }
        }
    }
}

// ---------------------------------------------------------------------------
// models
// ---------------------------------------------------------------------------

private data class Sample(val down: Long, val up: Long)

private data class AppRow(
    val uid: Int,
    val name: String,
    val packageName: String?,
    val icon: ImageBitmap?,
    val usage: Usage
)

private data class ActivityRow(
    val uid: Int,
    val name: String,
    val icon: ImageBitmap?,
    val from: Long,
    val to: Long,
    val usage: Usage
)

private data class Snapshot(
    val device: Usage = Usage(),
    val apps: List<AppRow> = emptyList(),
    val months: List<MonthUsage> = emptyList(),
    val hours: List<HourSlot> = emptyList(),
    val activity: List<ActivityRow> = emptyList(),
    val loading: Boolean = true
)

private data class Detail(
    val app: AppRow,
    val hours: List<HourSlot> = emptyList(),
    val sessions: List<ActivityRow> = emptyList(),
    val loading: Boolean = true
)

private const val WINDOW = 60

// ---------------------------------------------------------------------------
// screen
// ---------------------------------------------------------------------------

@Composable
private fun MeterScreen() {
    val context = LocalContext.current
    val repo = remember { NetStatsRepo(context) }
    val store = remember { ActivityStore(context.applicationContext) }

    var down by remember { mutableStateOf(0L) }
    var up by remember { mutableStateOf(0L) }
    var history by remember { mutableStateOf(listOf<Sample>()) }

    var rangeIsToday by remember { mutableStateOf(true) }
    var sortByBackground by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    var hasAccess by remember { mutableStateOf(repo.hasUsageAccess()) }
    var meterOn by remember { mutableStateOf(SpeedService.running) }
    var data by remember { mutableStateOf(Snapshot()) }
    var detail by remember { mutableStateOf<Detail?>(null) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasAccess = repo.hasUsageAccess()
                meterOn = SpeedService.running
                refresh++
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    // Live sampler — runs while the screen is open, independent of the service.
    LaunchedEffect(Unit) {
        var lastRx = TrafficStats.getTotalRxBytes()
        var lastTx = TrafficStats.getTotalTxBytes()
        var lastAt = SystemClock.elapsedRealtime()
        while (true) {
            delay(1000)
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val at = SystemClock.elapsedRealtime()
            val seconds = (at - lastAt) / 1000.0
            if (seconds > 0) {
                down = ((rx - lastRx) / seconds).toLong().coerceAtLeast(0)
                up = ((tx - lastTx) / seconds).toLong().coerceAtLeast(0)
                history = (history + Sample(down, up)).takeLast(WINDOW)
            }
            lastRx = rx
            lastTx = tx
            lastAt = at
        }
    }

    LaunchedEffect(rangeIsToday, refresh, hasAccess) {
        if (!hasAccess) {
            data = Snapshot(loading = false)
            return@LaunchedEffect
        }
        data = data.copy(loading = true)
        data = withContext(Dispatchers.IO) {
            // Take a reading on open so the log is current even if the meter is off.
            runCatching { store.sample(repo) }

            val (start, end) =
                if (rangeIsToday) NetStatsRepo.todayRange() else NetStatsRepo.thisMonthRange()

            val device = repo.deviceUsage(start, end)
            val raw = repo.appUsage(start, end).take(60)
            val apps = raw.map {
                AppRow(it.uid, it.name, it.packageName, it.icon?.toImageBitmap(), it.usage)
            }

            val months = NetStatsRepo.lastMonths(12).map { (label, s, e) ->
                MonthUsage(label, repo.deviceUsage(s, e))
            }

            val (dayStart, dayEnd) = NetStatsRepo.dayBounds()
            val hours = repo.hourlyTimeline(dayStart, minOf(dayEnd, System.currentTimeMillis()))

            val known = apps.associateBy { it.uid }
            val activity = store.recent(dayStart).map { entry ->
                val hit = known[entry.uid]
                val name = hit?.name ?: repo.describe(entry.uid).first
                ActivityRow(entry.uid, name, hit?.icon, entry.from, entry.to, entry.usage)
            }

            Snapshot(device, apps, months, hours, activity, loading = false)
        }
    }

    // Detail screen loads its own slice.
    LaunchedEffect(detail?.app?.uid) {
        val current = detail ?: return@LaunchedEffect
        if (!current.loading) return@LaunchedEffect
        val filled = withContext(Dispatchers.IO) {
            val (dayStart, dayEnd) = NetStatsRepo.dayBounds()
            val hours = repo.hourlyTimeline(
                dayStart, minOf(dayEnd, System.currentTimeMillis()), current.app.uid
            )
            val sessions = store.forApp(current.app.uid, dayStart).map {
                ActivityRow(it.uid, current.app.name, current.app.icon, it.from, it.to, it.usage)
            }
            current.copy(hours = hours, sessions = sessions, loading = false)
        }
        if (detail?.app?.uid == filled.app.uid) detail = filled
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Prefs.setMeterEnabled(context, true)
            SpeedService.start(context)
            meterOn = true
        }
    }

    // --- cutting an app off -------------------------------------------------

    var blocked by remember { mutableStateOf(Blocklist.packages(context)) }
    var pendingBlock by remember { mutableStateOf<String?>(null) }

    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val pkg = pendingBlock
        pendingBlock = null
        if (result.resultCode == Activity.RESULT_OK && pkg != null) {
            Blocklist.set(context, pkg, true)
            blocked = Blocklist.packages(context)
            BlockVpnService.sync(context)
        }
    }

    fun setBlocked(pkg: String, on: Boolean) {
        if (!on) {
            Blocklist.set(context, pkg, false)
            blocked = Blocklist.packages(context)
            BlockVpnService.sync(context)
            return
        }
        val consent = VpnService.prepare(context)
        if (consent == null) {
            Blocklist.set(context, pkg, true)
            blocked = Blocklist.packages(context)
            BlockVpnService.sync(context)
        } else {
            pendingBlock = pkg
            vpnLauncher.launch(consent)
        }
    }

    fun openBackgroundDataSettings(pkg: String) {
        val direct = Intent(
            Settings.ACTION_IGNORE_BACKGROUND_DATA_RESTRICTIONS_SETTINGS,
            Uri.parse("package:$pkg")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val fallback = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$pkg")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        runCatching { context.startActivity(direct) }
            .onFailure { runCatching { context.startActivity(fallback) } }
    }

    var alertMb by remember { mutableIntStateOf(Prefs.alertThresholdMb(context)) }

    fun toggleMeter(on: Boolean) {
        if (on) {
            val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            if (needsPermission) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                Prefs.setMeterEnabled(context, true)
                SpeedService.start(context)
                meterOn = true
            }
        } else {
            Prefs.setMeterEnabled(context, false)
            SpeedService.stop(context)
            meterOn = false
        }
    }

    val appsSorted = remember(data.apps, sortByBackground) {
        if (sortByBackground) data.apps.sortedByDescending { it.usage.background }
        else data.apps.sortedByDescending { it.usage.total }
    }

    Box(Modifier.fillMaxSize().background(Ink.Background)) {

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 44.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            item { Masthead() }
            item { LivePanel(down, up, history) }
            item { MeterToggle(meterOn, ::toggleMeter) }

            if (!hasAccess) item { UsageAccessCard(context) }

            item { RangePicker(rangeIsToday) { rangeIsToday = it } }
            item { TotalsRow(data.device) }

            if (rangeIsToday) {
                item { HourCard(data.hours) }
            }

            item { BackgroundCard(data.device, data.apps) }

            item {
                AlertsCard(alertMb) {
                    alertMb = it
                    Prefs.setAlertThresholdMb(context, it)
                }
            }

            if (blocked.isNotEmpty()) {
                item { BlockedCard(blocked.size) }
            }

            item {
                SectionHeader(
                    title = if (rangeIsToday) "Apps today" else "Apps this month",
                    caption = if (data.loading) "READING…" else "${data.apps.size} APPS"
                )
            }
            item { SortPills(sortByBackground) { sortByBackground = it } }

            if (appsSorted.isEmpty() && !data.loading) {
                item {
                    Note(
                        if (hasAccess) "No traffic recorded for this period yet."
                        else "Grant usage access above to see the app breakdown."
                    )
                }
            }

            items(appsSorted) { app ->
                AppUsageRow(
                    app = app,
                    scale = appsSorted.firstOrNull()?.usage?.total ?: 1L,
                    isBlocked = app.packageName in blocked,
                    onClick = { detail = Detail(app) }
                )
            }

            item {
                Spacer(Modifier.height(8.dp))
                SectionHeader(title = "Activity log", caption = "TODAY, NEWEST FIRST")
            }

            if (data.activity.isEmpty()) {
                item {
                    Note(
                        "Nothing logged yet. The log fills in while the meter is running — " +
                            "it takes a reading every minute and notes what changed."
                    )
                }
            }

            items(data.activity) { entry -> ActivityRowItem(entry) }

            item {
                Spacer(Modifier.height(8.dp))
                SectionHeader(title = "Month by month", caption = "LAST 12")
            }

            items(data.months) { month ->
                MonthRow(month, data.months.maxOfOrNull { it.usage.total } ?: 1L)
            }

            item { Footnote() }
        }

        detail?.let { current ->
            BackHandler { detail = null }
            AppDetailScreen(
                detail = current,
                isBlocked = current.app.packageName in blocked,
                onBlockChange = { on -> current.app.packageName?.let { setBlocked(it, on) } },
                onOpenBackgroundSettings = {
                    current.app.packageName?.let { openBackgroundDataSettings(it) }
                },
                onClose = { detail = null }
            )
        }
    }
}

// ---------------------------------------------------------------------------
// live panel
// ---------------------------------------------------------------------------

@Composable
private fun Masthead() {
    Column(Modifier.padding(bottom = 4.dp)) {
        Text("NET METER", style = Legend, color = Ink.Faint)
        Spacer(Modifier.height(2.dp))
        Text("What used your data, when, and whether you were looking", style = Body, color = Ink.Muted)
    }
}

@Composable
private fun LivePanel(down: Long, up: Long, history: List<Sample>) {
    Panel {
        Row(verticalAlignment = Alignment.Bottom) {
            Channel("DOWN", down, Ink.Down, Modifier.weight(1f))
            Channel("UP", up, Ink.Up, Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Waveform(history, Modifier.fillMaxWidth().height(104.dp))
        Spacer(Modifier.height(8.dp))
        val peak = history.maxOfOrNull { max(it.down, it.up) } ?: 0L
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("60 SECONDS", style = Legend, color = Ink.Faint)
            Text("PEAK " + Format.speed(peak), style = Legend, color = Ink.Faint)
        }
    }
}

@Composable
private fun Channel(label: String, value: Long, color: Color, modifier: Modifier) {
    val (number, unit) = Format.speedParts(value)
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(color); Spacer(Modifier.width(6.dp))
            Text(label, style = Legend, color = Ink.Muted)
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(number, style = Readout, color = color)
            Spacer(Modifier.width(4.dp))
            Text(
                unit, style = Legend.copy(fontSize = 11.sp), color = Ink.Muted,
                modifier = Modifier.padding(bottom = 5.dp)
            )
        }
    }
}

@Composable
private fun Waveform(history: List<Sample>, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val mid = h / 2f

        drawLine(Ink.Hairline, Offset(0f, mid), Offset(w, mid), strokeWidth = 1f)
        if (history.size < 2) return@Canvas

        val peak = max(history.maxOf { max(it.down, it.up) }, 256L * 1024L).toFloat()
        val step = w / (WINDOW - 1).toFloat()
        val offset = WINDOW - history.size
        val amplitude = mid - 3f

        fun x(i: Int) = (offset + i) * step
        fun y(value: Long, above: Boolean): Float {
            val ratio = (value / peak).coerceIn(0f, 1f)
            return if (above) mid - ratio * amplitude else mid + ratio * amplitude
        }

        fun channel(above: Boolean, pick: (Sample) -> Long, color: Color) {
            val area = Path().apply {
                moveTo(x(0), mid)
                history.forEachIndexed { i, s -> lineTo(x(i), y(pick(s), above)) }
                lineTo(x(history.lastIndex), mid)
                close()
            }
            drawPath(
                path = area,
                brush = Brush.verticalGradient(
                    colors = if (above) listOf(color.copy(alpha = 0.55f), color.copy(alpha = 0.04f))
                    else listOf(color.copy(alpha = 0.04f), color.copy(alpha = 0.55f)),
                    startY = if (above) 0f else mid,
                    endY = if (above) mid else h
                )
            )
            val line = Path().apply {
                moveTo(x(0), y(pick(history.first()), above))
                history.forEachIndexed { i, s -> lineTo(x(i), y(pick(s), above)) }
            }
            drawPath(path = line, color = color, style = Stroke(width = 2.5f))
        }

        channel(true, { it.down }, Ink.Down)
        channel(false, { it.up }, Ink.Up)
    }
}

// ---------------------------------------------------------------------------
// when
// ---------------------------------------------------------------------------

@Composable
private fun HourCard(hours: List<HourSlot>) {
    Panel {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("TODAY, HOUR BY HOUR", style = Legend, color = Ink.Muted)
            SplitLegend()
        }
        Spacer(Modifier.height(14.dp))
        HourBars(hours)
        Spacer(Modifier.height(8.dp))

        val busiest = hours.maxByOrNull { it.usage.total }
        Text(
            if (busiest == null || busiest.usage.total == 0L)
                "Nothing recorded yet today."
            else
                "Busiest hour ${NetStatsRepo.hourLabel(busiest.hour)}–" +
                    "${NetStatsRepo.hourLabel((busiest.hour + 1) % 24)} · " +
                    "${Format.bytes(busiest.usage.total)}",
            style = Body.copy(fontSize = 12.sp),
            color = Ink.Muted
        )
    }
}

@Composable
private fun HourBars(hours: List<HourSlot>) {
    val peak = max(hours.maxOfOrNull { it.usage.total } ?: 0L, 1L)
    val fullHeight = 84f

    Row(
        Modifier.fillMaxWidth().height(fullHeight.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (h in 0 until 24) {
            val slot = hours.getOrNull(h)?.usage ?: Usage()
            val fraction = (slot.total.toFloat() / peak).coerceIn(0f, 1f)
            val bar = if (slot.total > 0) max(fraction * fullHeight, 2.5f) else 0f
            val mobileShare = if (slot.total > 0) slot.mobile.toFloat() / slot.total else 0f

            Column(
                Modifier.weight(1f).fillMaxHeight(),
                verticalArrangement = Arrangement.Bottom
            ) {
                if (bar > 0) {
                    val mobileHeight = bar * mobileShare
                    val wifiHeight = bar - mobileHeight
                    if (wifiHeight > 0.4f) {
                        Box(
                            Modifier.fillMaxWidth().height(wifiHeight.dp)
                                .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp))
                                .background(Ink.Down)
                        )
                    }
                    if (mobileHeight > 0.4f) {
                        Box(Modifier.fillMaxWidth().height(mobileHeight.dp).background(Ink.Up))
                    }
                } else {
                    Box(Modifier.fillMaxWidth().height(1.5.dp).background(Ink.Hairline))
                }
            }
        }
    }

    Spacer(Modifier.height(6.dp))

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf(0, 4, 8, 12, 16, 20).forEach {
            Text(NetStatsRepo.hourLabel(it), style = Legend.copy(fontSize = 9.sp), color = Ink.Faint)
        }
        Text("12a", style = Legend.copy(fontSize = 9.sp), color = Ink.Faint)
    }
}

// ---------------------------------------------------------------------------
// why
// ---------------------------------------------------------------------------

@Composable
private fun BackgroundCard(device: Usage, apps: List<AppRow>) {
    val fg = apps.sumOf { it.usage.foreground }
    val bg = apps.sumOf { it.usage.background }
    val total = (fg + bg).coerceAtLeast(1L)
    val share = (bg.toFloat() / total * 100).roundToInt()

    val offenders = apps
        .filter { it.usage.background > 0 }
        .sortedByDescending { it.usage.background }
        .take(3)

    Panel {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("WHILE YOU WEREN'T LOOKING", style = Legend, color = Ink.Muted)
            Text("$share%", style = ReadoutSmall.copy(fontSize = 14.sp), color = Ink.Up)
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                .background(Ink.Hairline)
        ) {
            val fgShare = fg.toFloat() / total
            if (fgShare > 0f) {
                Box(Modifier.fillMaxWidth(fgShare).fillMaxHeight().background(Ink.Text))
            }
            Box(Modifier.weight(1f).fillMaxHeight().background(Ink.Up))
        }

        Spacer(Modifier.height(10.dp))

        Row {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(Ink.Text); Spacer(Modifier.width(5.dp))
                Text("IN THE APP  ${Format.bytes(fg)}", style = Legend.copy(fontSize = 9.sp), color = Ink.Faint)
            }
            Spacer(Modifier.width(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(Ink.Up); Spacer(Modifier.width(5.dp))
                Text("BACKGROUND  ${Format.bytes(bg)}", style = Legend.copy(fontSize = 9.sp), color = Ink.Faint)
            }
        }

        if (offenders.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text(
                "Most of the background traffic came from " +
                    offenders.joinToString(", ") { it.name } + ".",
                style = Body.copy(fontSize = 12.sp),
                color = Ink.Muted
            )
        }
    }
}

// ---------------------------------------------------------------------------
// controls
// ---------------------------------------------------------------------------

@Composable
private fun MeterToggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Ink.Surface)
            .border(1.dp, Ink.Hairline, RoundedCornerShape(14.dp))
            .clickable { onChange(!on) }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Show speed in the status bar", style = Body, color = Ink.Text)
            Spacer(Modifier.height(2.dp))
            Text(
                if (on) "Running — also filling the activity log every minute"
                else "Off — the activity log only updates when you open the app",
                style = Body.copy(fontSize = 12.sp), color = Ink.Muted
            )
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Ink.Background,
                checkedTrackColor = Ink.Down,
                uncheckedThumbColor = Ink.Muted,
                uncheckedTrackColor = Ink.Hairline,
                uncheckedBorderColor = Ink.Hairline
            )
        )
    }
}

@Composable
private fun UsageAccessCard(context: Context) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Ink.Raised)
            .border(1.dp, Ink.Up.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text("USAGE ACCESS NEEDED", style = Legend, color = Ink.Up)
        Spacer(Modifier.height(6.dp))
        Text(
            "Android keeps the per-app figures behind a separate switch. Open " +
                "Settings, find Net Meter in the list, and turn it on.",
            style = Body, color = Ink.Muted
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Open settings",
            style = Body.copy(fontSize = 13.sp), color = Ink.Background,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Ink.Up)
                .clickable {
                    context.startActivity(
                        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                .padding(horizontal = 16.dp, vertical = 9.dp)
        )
    }
}

@Composable
private fun RangePicker(todaySelected: Boolean, onSelect: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Ink.Surface).padding(4.dp)
    ) {
        Tab("TODAY", todaySelected, Modifier.weight(1f)) { onSelect(true) }
        Tab("THIS MONTH", !todaySelected, Modifier.weight(1f)) { onSelect(false) }
    }
}

@Composable
private fun SortPills(byBackground: Boolean, onSelect: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pill("MOST DATA", !byBackground) { onSelect(false) }
        Pill("MOST BACKGROUND", byBackground) { onSelect(true) }
    }
}

@Composable
private fun Pill(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        style = Legend.copy(fontSize = 9.sp),
        color = if (selected) Ink.Background else Ink.Muted,
        modifier = Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) Ink.Down else Ink.Surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
private fun Tab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(9.dp))
            .background(if (selected) Ink.Raised else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = Legend, color = if (selected) Ink.Down else Ink.Faint)
    }
}

// ---------------------------------------------------------------------------
// totals
// ---------------------------------------------------------------------------

@Composable
private fun TotalsRow(usage: Usage) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Tile("TOTAL", usage.total, Ink.Text, Modifier.weight(1f))
        Tile("MOBILE", usage.mobile, Ink.Up, Modifier.weight(1f))
        Tile("WI-FI", usage.wifi, Ink.Down, Modifier.weight(1f))
    }
}

@Composable
private fun Tile(label: String, value: Long, color: Color, modifier: Modifier) {
    val (number, unit) = Format.bytesParts(value)
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Ink.Surface)
            .border(1.dp, Ink.Hairline, RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        Text(label, style = Legend, color = Ink.Faint)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(number, style = ReadoutSmall, color = color, maxLines = 1)
            Spacer(Modifier.width(3.dp))
            Text(
                unit, style = Legend.copy(fontSize = 9.sp), color = Ink.Muted,
                modifier = Modifier.padding(bottom = 3.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// rows
// ---------------------------------------------------------------------------

@Composable
private fun AppUsageRow(app: AppRow, scale: Long, isBlocked: Boolean, onClick: () -> Unit) {
    val bgPercent = (app.usage.backgroundShare * 100).roundToInt()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Ink.Surface)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(app.icon, app.name)
        Spacer(Modifier.width(12.dp))

        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    app.name, style = Body, color = Ink.Text,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (isBlocked) {
                    Spacer(Modifier.width(7.dp))
                    Text(
                        "CUT OFF",
                        style = Legend.copy(fontSize = 8.sp),
                        color = Ink.Background,
                        modifier = Modifier.clip(RoundedCornerShape(5.dp)).background(Ink.Up)
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                if (bgPercent >= 1) "$bgPercent% in the background" else "all while you had it open",
                style = Body.copy(fontSize = 11.sp),
                color = if (bgPercent >= 60) Ink.Up else Ink.Faint
            )
            Spacer(Modifier.height(7.dp))
            SplitBar(app.usage.mobile, app.usage.wifi, scale)
        }

        Spacer(Modifier.width(12.dp))
        Text(Format.bytes(app.usage.total), style = ReadoutSmall.copy(fontSize = 14.sp), color = Ink.Text)
    }
}

@Composable
private fun ActivityRowItem(entry: ActivityRow) {
    val background = entry.usage.background > entry.usage.foreground
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Ink.Surface).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.width(64.dp)) {
            Text(
                NetStatsRepo.clockLabel(entry.to),
                style = ReadoutSmall.copy(fontSize = 12.sp), color = Ink.Text
            )
            Spacer(Modifier.height(2.dp))
            Text(
                if (background) "BACKGROUND" else "IN APP",
                style = Legend.copy(fontSize = 8.sp),
                color = if (background) Ink.Up else Ink.Faint
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, style = Body, color = Ink.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(
                if (entry.usage.mobile > 0 && entry.usage.wifi > 0)
                    "${Format.bytes(entry.usage.mobile)} mobile · ${Format.bytes(entry.usage.wifi)} Wi-Fi"
                else if (entry.usage.mobile > 0) "on mobile data" else "on Wi-Fi",
                style = Body.copy(fontSize = 11.sp), color = Ink.Faint
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            Format.bytes(entry.usage.total),
            style = ReadoutSmall.copy(fontSize = 14.sp),
            color = if (entry.usage.mobile > entry.usage.wifi) Ink.Up else Ink.Down
        )
    }
}

@Composable
private fun MonthRow(month: MonthUsage, scale: Long) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Ink.Surface)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(month.label, style = Body.copy(fontSize = 13.sp), color = Ink.Muted, modifier = Modifier.width(78.dp))
        Column(Modifier.weight(1f)) { SplitBar(month.usage.mobile, month.usage.wifi, scale) }
        Spacer(Modifier.width(12.dp))
        Text(Format.bytes(month.usage.total), style = ReadoutSmall.copy(fontSize = 14.sp), color = Ink.Text)
    }
}

// ---------------------------------------------------------------------------
// app detail
// ---------------------------------------------------------------------------

@Composable
private fun AppDetailScreen(
    detail: Detail,
    isBlocked: Boolean,
    onBlockChange: (Boolean) -> Unit,
    onOpenBackgroundSettings: () -> Unit,
    onClose: () -> Unit
) {
    val app = detail.app
    LazyColumn(
        Modifier.fillMaxSize().background(Ink.Background),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 44.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "← BACK",
                style = Legend,
                color = Ink.Muted,
                modifier = Modifier.clickable(onClick = onClose).padding(vertical = 6.dp)
            )
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(app.icon, app.name, 48.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(app.name, style = Body.copy(fontSize = 19.sp), color = Ink.Text)
                    Spacer(Modifier.height(2.dp))
                    Text("UID ${app.uid}", style = Legend, color = Ink.Faint)
                }
            }
        }

        item { TotalsRow(app.usage) }

        if (app.packageName != null) {
            item {
                RestrictCard(
                    appName = app.name,
                    isBlocked = isBlocked,
                    onBlockChange = onBlockChange,
                    onOpenBackgroundSettings = onOpenBackgroundSettings
                )
            }
        }

        item {
            Panel {
                Text("SPLIT BY WHERE YOU WERE", style = Legend, color = Ink.Muted)
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        .background(Ink.Hairline)
                ) {
                    val total = app.usage.total.coerceAtLeast(1L)
                    val fgShare = app.usage.foreground.toFloat() / total
                    if (fgShare > 0f) {
                        Box(Modifier.fillMaxWidth(fgShare).fillMaxHeight().background(Ink.Text))
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().background(Ink.Up))
                }
                Spacer(Modifier.height(10.dp))
                Row {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Dot(Ink.Text); Spacer(Modifier.width(5.dp))
                        Text(
                            "IN THE APP  ${Format.bytes(app.usage.foreground)}",
                            style = Legend.copy(fontSize = 9.sp), color = Ink.Faint
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Dot(Ink.Up); Spacer(Modifier.width(5.dp))
                        Text(
                            "BACKGROUND  ${Format.bytes(app.usage.background)}",
                            style = Legend.copy(fontSize = 9.sp), color = Ink.Faint
                        )
                    }
                }
            }
        }

        item {
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("TODAY, HOUR BY HOUR", style = Legend, color = Ink.Muted)
                    SplitLegend()
                }
                Spacer(Modifier.height(14.dp))
                HourBars(detail.hours)
            }
        }

        item { SectionHeader(title = "When it ran", caption = "TODAY, NEWEST FIRST") }

        if (detail.sessions.isEmpty()) {
            item {
                Note(
                    if (detail.loading) "Loading…"
                    else "Nothing logged for this app yet today. The log fills in " +
                        "while the meter is running."
                )
            }
        }

        items(detail.sessions) { session -> ActivityRowItem(session) }
    }
}

// ---------------------------------------------------------------------------
// restricting an app
// ---------------------------------------------------------------------------

@Composable
private fun RestrictCard(
    appName: String,
    isBlocked: Boolean,
    onBlockChange: (Boolean) -> Unit,
    onOpenBackgroundSettings: () -> Unit
) {
    Panel {
        Text("RESTRICT THIS APP", style = Legend, color = Ink.Muted)
        Spacer(Modifier.height(12.dp))

        // Option 1 — Android's own switch. Precise, and nothing else changes.
        Text("Turn off its background data", style = Body, color = Ink.Text)
        Spacer(Modifier.height(3.dp))
        Text(
            "Android has a per-app switch for exactly this. $appName keeps working " +
                "while it's open and gets nothing when it isn't. Only an app's own " +
                "settings screen can flip it, so this takes you straight there.",
            style = Body.copy(fontSize = 12.sp), color = Ink.Muted
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Open its data settings",
            style = Body.copy(fontSize = 13.sp), color = Ink.Background,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(Ink.Down)
                .clickable(onClick = onOpenBackgroundSettings)
                .padding(horizontal = 16.dp, vertical = 9.dp)
        )

        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Ink.Hairline))
        Spacer(Modifier.height(18.dp))

        // Option 2 — the blunt one, handled inside this app.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Cut it off completely", style = Body, color = Ink.Text)
                Spacer(Modifier.height(3.dp))
                Text(
                    if (isBlocked)
                        "$appName currently has no internet at all, open or not."
                    else
                        "No internet at all — background or foreground. Uses a local " +
                            "tunnel that swallows only this app's traffic. Nothing " +
                            "leaves your phone, and no other app is affected.",
                    style = Body.copy(fontSize = 12.sp),
                    color = if (isBlocked) Ink.Up else Ink.Muted
                )
            }
            Spacer(Modifier.width(10.dp))
            Switch(
                checked = isBlocked, onCheckedChange = onBlockChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Ink.Background,
                    checkedTrackColor = Ink.Up,
                    uncheckedThumbColor = Ink.Muted,
                    uncheckedTrackColor = Ink.Hairline,
                    uncheckedBorderColor = Ink.Hairline
                )
            )
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "Android allows one VPN at a time, so this can't run alongside another " +
                "VPN app.",
            style = Body.copy(fontSize = 11.sp), color = Ink.Faint
        )
    }
}

@Composable
private fun AlertsCard(thresholdMb: Int, onChange: (Int) -> Unit) {
    Panel {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("WARN ME ABOUT BACKGROUND SPIKES", style = Legend, color = Ink.Muted)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (thresholdMb <= Prefs.ALERT_OFF)
                "Off. Nothing will be flagged."
            else
                "Notify me when any app moves more than $thresholdMb MB in a day " +
                    "while it isn't on screen.",
            style = Body.copy(fontSize = 12.sp), color = Ink.Muted
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(50, 100, 250).forEach { mb ->
                Pill("$mb MB", thresholdMb == mb) { onChange(mb) }
            }
            Pill("OFF", thresholdMb <= Prefs.ALERT_OFF) { onChange(Prefs.ALERT_OFF) }
        }
    }
}

@Composable
private fun BlockedCard(count: Int) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Ink.Raised)
            .border(1.dp, Ink.Up.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Dot(Ink.Up)
        Spacer(Modifier.width(10.dp))
        Text(
            if (count == 1) "1 app is cut off from the network"
            else "$count apps are cut off from the network",
            style = Body.copy(fontSize = 13.sp), color = Ink.Text
        )
    }
}

// ---------------------------------------------------------------------------
// small pieces
// ---------------------------------------------------------------------------

@Composable
private fun Panel(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Ink.Surface)
            .border(1.dp, Ink.Hairline, RoundedCornerShape(18.dp)).padding(18.dp),
        content = content
    )
}

@Composable
private fun AppIcon(icon: ImageBitmap?, name: String, size: androidx.compose.ui.unit.Dp = 38.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 3.6f)).background(Ink.Raised),
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(size * 0.74f))
        } else {
            Text(
                name.take(1).uppercase(),
                style = ReadoutSmall.copy(fontSize = (size.value * 0.38f).sp),
                color = Ink.Muted
            )
        }
    }
}

@Composable
private fun SplitLegend() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Dot(Ink.Up); Spacer(Modifier.width(4.dp))
        Text("MOBILE", style = Legend.copy(fontSize = 9.sp), color = Ink.Faint)
        Spacer(Modifier.width(10.dp))
        Dot(Ink.Down); Spacer(Modifier.width(4.dp))
        Text("WI-FI", style = Legend.copy(fontSize = 9.sp), color = Ink.Faint)
    }
}

@Composable
private fun SectionHeader(title: String, caption: String) {
    Column(Modifier.padding(top = 10.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = Body.copy(fontSize = 15.sp), color = Ink.Text)
            SplitLegend()
        }
        Spacer(Modifier.height(4.dp))
        Text(caption, style = Legend, color = Ink.Faint)
    }
}

@Composable
private fun SplitBar(mobile: Long, wifi: Long, scale: Long) {
    val total = (mobile + wifi).coerceAtLeast(0)
    val fraction = if (scale > 0) (total.toFloat() / scale).coerceIn(0.02f, 1f) else 0.02f

    Box(
        Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Ink.Hairline)
    ) {
        Row(Modifier.fillMaxWidth(fraction).height(5.dp).clip(RoundedCornerShape(3.dp))) {
            val mobileWeight = if (total > 0) mobile.toFloat() / total else 0f
            if (mobileWeight > 0f) {
                Box(Modifier.fillMaxWidth(mobileWeight).height(5.dp).background(Ink.Up))
            }
            Box(Modifier.weight(1f).height(5.dp).background(Ink.Down))
        }
    }
}

@Composable
private fun Dot(color: Color) {
    Box(Modifier.size(6.dp).clip(RoundedCornerShape(3.dp)).background(color))
}

@Composable
private fun Note(text: String) {
    Text(
        text, style = Body.copy(fontSize = 13.sp), color = Ink.Faint,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(Ink.Surface).padding(16.dp)
    )
}

@Composable
private fun Footnote() {
    Spacer(Modifier.height(14.dp))
    Text(
        "Android records what each app moved and whether it was on screen at the " +
            "time — it never sees what the data contained. Traffic is stored in " +
            "blocks, so the hourly shape is close but not exact, and detailed " +
            "per-app records only go back so far.",
        style = Body.copy(fontSize = 11.sp), color = Ink.Faint
    )
}

// ---------------------------------------------------------------------------

private fun Drawable.toImageBitmap(px: Int = 96): ImageBitmap {
    val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    setBounds(0, 0, px, px)
    draw(canvas)
    return bitmap.asImageBitmap()
}
